package com.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.dao.InsuranceQuoteGenerationIMPL;
import com.exception.InsuranceQuoteGenerationException;
import com.util.DBConnection;

import junit.framework.Assert;

public class DBConnectionTest {

	static InsuranceQuoteGenerationIMPL daoTest;
	static Connection dbCon;

	@BeforeClass
	public static void initialise() {
		daoTest = new InsuranceQuoteGenerationIMPL();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	/**
	 * Test case for Establishing Connection
	 * @throws IOException 
	 * @throws SQLException 
	 * 
	 * @throws DonorException
	 **/
	@Test
	public void test() throws InsuranceQuoteGenerationException, SQLException, IOException {
		Connection dbCon = DBConnection.getInstance().getConnection();
		Assert.assertNotNull(dbCon);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daoTest = null;
		dbCon = null;
	}
}
