package com.exception;

public class InsuranceQuoteGenerationException extends Exception{

	public InsuranceQuoteGenerationException(String message) 
	{
		
		System.out.println("Check Some thing went wrong");
	}
}
